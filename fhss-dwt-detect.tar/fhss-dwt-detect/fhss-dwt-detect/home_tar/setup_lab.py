"""
Task 1: SETUP LAB
Tao file stego_audio.wav voi tin giau san de sinh vien phan tich.
"""
import numpy as np
import pywt
from scipy.io.wavfile import read, write
import random

WAVELET = 'db4'
LEVEL = 5
DELTA = 200.0
STRIDE = 30


def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)


def qim_embed(value, bit, delta):
    if bit == 0:
        return round(value / delta) * delta
    else:
        return round((value - delta / 2) / delta) * delta + delta / 2


def embed_message(audio, message_bits, hopping_pattern):
    coeffs = pywt.wavedec(audio, WAVELET, level=LEVEL)
    coeffs = [c.copy() for c in coeffs]
    subband_counter = [0] * len(coeffs)
    for i, bit in enumerate(message_bits):
        subband_idx = hopping_pattern[i]
        sub = coeffs[subband_idx]
        offset = STRIDE * (subband_counter[subband_idx] + 1)
        coeff_idx = offset % len(sub)
        sub[coeff_idx] = qim_embed(sub[coeff_idx], int(bit), DELTA)
        subband_counter[subband_idx] += 1
    audio_stego = pywt.waverec(coeffs, WAVELET)
    return audio_stego[:len(audio)]


def main():
    print("=" * 60)
    print("TASK 1: SETUP LAB - Chuan bi du lieu de phan tich")
    print("=" * 60)
    fs, audio = read("original_audio.wav")
    if audio.ndim > 1:
        audio = audio[:, 0]
    audio = audio.astype(np.float64)
    print(f"Tan so lay mau: {fs} Hz")
    print(f"Do dai audio: {len(audio)} samples ({len(audio)/fs:.2f} giay)")
    with open("message.txt", "r", encoding="utf-8") as f:
        message = f.read().strip()
    print(f"Thong diep can giau: '{message}'")
    bits = text_to_bits(message)
    print(f"So bit: {len(bits)}")
    random.seed(42)
    hopping = [random.randint(0, 5) for _ in range(len(bits))]
    audio_stego = embed_message(audio, bits, hopping)
    audio_stego_int = np.clip(audio_stego, -32768, 32767).astype(np.int16)
    write("stego_audio.wav", fs, audio_stego_int)
    mse = np.mean((audio - audio_stego) ** 2)
    if mse > 0:
        psnr = 10 * np.log10((32767 ** 2) / mse)
        print(f"PSNR: {psnr:.2f} dB")
    print("\n>>> stego_audio.wav da duoc tao")
    print(">>> Tham so cong khai: DELTA=200, WAVELET='db4', LEVEL=5")
    print(">>> Bi mat: hopping_pattern")


if __name__ == "__main__":
    main()
