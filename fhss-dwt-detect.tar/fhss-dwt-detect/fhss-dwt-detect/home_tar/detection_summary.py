"""
Task 7: DETECTION SUMMARY
Tong hop ket qua tu 4 phuong phap, dua ra ket luan cuoi cung.
"""
import os


def check_file_contains(path, keyword):
    if not os.path.exists(path):
        return False
    with open(path, "r") as f:
        return keyword.lower() in f.read().lower()


def main():
    print("=" * 60)
    print("TASK 7: DETECTION SUMMARY - Tong hop 4 phuong phap")
    print("=" * 60)
    methods = []
    methods.append(("Spectrogram (sonic-visualiser)", False, "Khong thay vach sang"))
    methods.append(("Spectrum (sonic-visualiser)", False, "Khong co dinh tan so bat thuong"))
    energy_ok = check_file_contains("energy_report.txt", "ineffective")
    methods.append(("Energy Analysis", not energy_ok, "Khong phat hien band bat thuong"))
    dwt_ok = check_file_contains("dwt_report.txt", "bits detected")
    methods.append(("DWT Difference", dwt_ok, "So sanh he so DWT vs audio goc"))
    stats_ok = check_file_contains("stats_report.txt", "suspicious")
    methods.append(("Statistical (blind)", stats_ok, "Chi-square cho QIM"))
    report = ["DETECTION SUMMARY", "=" * 50]
    for name, detected, note in methods:
        status = "DETECTED" if detected else "NOT DETECTED"
        line = f"  [{status}] {name}: {note}"
        report.append(line)
        print(line)
    detected_count = sum(1 for _, d, _ in methods if d)
    report.append("")
    report.append(f"Tong: {detected_count}/{len(methods)} phuong phap phat hien.")
    if detected_count >= 2:
        verdict = "FINAL VERDICT: STEGANOGRAPHY DETECTED"
    elif detected_count == 1:
        verdict = "FINAL VERDICT: SUSPICIOUS - can phan tich them"
    else:
        verdict = "FINAL VERDICT: CLEAN - khong phat hien"
    report.append(verdict)
    print(f"\n>>> {verdict}")
    with open("detection_summary.txt", "w") as f:
        f.write("\n".join(report))
    print(">>> Bao cao: detection_summary.txt")


if __name__ == "__main__":
    main()
