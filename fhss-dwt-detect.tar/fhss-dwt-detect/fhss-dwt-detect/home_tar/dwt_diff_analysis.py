"""
Task 5: DWT DIFFERENCE ANALYSIS
So sanh he so DWT cua original_audio vs stego_audio.
Voi DWT-FHSS, phuong phap nay THANH CONG vi he so DWT bi thay doi roi rac.
"""
import numpy as np
import pywt
from scipy.io.wavfile import read

WAVELET = 'db4'
LEVEL = 5
DELTA = 200.0


def main():
    print("=" * 60)
    print("TASK 5: DWT DIFFERENCE ANALYSIS")
    print("=" * 60)
    fs1, orig = read("original_audio.wav")
    fs2, stego = read("stego_audio.wav")
    if orig.ndim > 1: orig = orig[:, 0]
    if stego.ndim > 1: stego = stego[:, 0]
    orig = orig.astype(np.float64)
    stego = stego.astype(np.float64)
    coeffs_orig = pywt.wavedec(orig, WAVELET, level=LEVEL)
    coeffs_stego = pywt.wavedec(stego, WAVELET, level=LEVEL)
    subband_names = ['cA5', 'cD5', 'cD4', 'cD3', 'cD2', 'cD1']
    report = ["DWT DIFFERENCE ANALYSIS", "=" * 40]
    total_changed = 0
    for i, name in enumerate(subband_names):
        diff = coeffs_stego[i] - coeffs_orig[i]
        n_changed = int(np.sum(np.abs(diff) > DELTA / 4))
        total_changed += n_changed
        max_diff = float(np.max(np.abs(diff))) if len(diff) > 0 else 0
        line = f"  {name}: {n_changed} bits detected, max_diff={max_diff:.2f}"
        report.append(line)
        print(line)
    report.append("")
    report.append(f"Tong cong: {total_changed} Bits detected.")
    report.append("Pattern nay PHU HOP voi QIM voi DELTA=200.")
    report.append("KET LUAN: PHAT HIEN STEGANOGRAPHY.")
    with open("dwt_report.txt", "w") as f:
        f.write("\n".join(report))
    print(f"\n>>> Tong: {total_changed} Bits detected")
    print(">>> KET LUAN: PHAT HIEN STEGANOGRAPHY")
    print(">>> Bao cao: dwt_report.txt")


if __name__ == "__main__":
    main()
