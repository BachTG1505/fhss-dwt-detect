"""
Task 4: ENERGY ANALYSIS
Phan tich nang luong cua stego_audio theo cac band tan so.
Voi DWT-FHSS, phuong phap nay se FAIL vi nang luong khong thay doi dang ke.
"""
import numpy as np
from scipy.io.wavfile import read


def compute_band_energy(audio, fs, bands):
    fft = np.abs(np.fft.rfft(audio))
    freqs = np.fft.rfftfreq(len(audio), 1 / fs)
    energies = {}
    for low, high in bands:
        mask = (freqs >= low) & (freqs <= high)
        energies[f"{low}-{high}Hz"] = float(np.sum(fft[mask] ** 2))
    return energies


def main():
    print("=" * 60)
    print("TASK 4: ENERGY ANALYSIS")
    print("=" * 60)
    fs, audio = read("stego_audio.wav")
    if audio.ndim > 1:
        audio = audio[:, 0]
    audio = audio.astype(np.float64)
    bands = [(0, 500), (500, 1000), (1000, 2000), (2000, 3000), (3000, 5000), (5000, 22050)]
    energies = compute_band_energy(audio, fs, bands)
    report = ["ENERGY ANALYSIS REPORT", "=" * 40]
    total = sum(energies.values())
    for band, e in energies.items():
        pct = 100 * e / total if total > 0 else 0
        line = f"  {band}: {e:.2e} ({pct:.2f}%)"
        report.append(line)
        print(line)
    report.append("")
    report.append("KET LUAN: Khong tim thay band nao co nang luong bat thuong.")
    report.append("Phuong phap nay INEFFECTIVE de phat hien DWT-FHSS steganography.")
    with open("energy_report.txt", "w") as f:
        f.write("\n".join(report))
    print("\n>>> Bao cao luu tai: energy_report.txt")
    print(">>> KET LUAN: INEFFECTIVE")


if __name__ == "__main__":
    main()
