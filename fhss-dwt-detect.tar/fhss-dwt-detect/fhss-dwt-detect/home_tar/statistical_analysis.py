"""
Task 6: BLIND STATISTICAL ANALYSIS
Phan tich thong ke tren stego_audio (KHONG can audio goc).
Dua vao tinh chat QIM: he so wavelet sau khi nhung se phan bo kep quanh boi cua DELTA va DELTA/2.
"""
import numpy as np
import pywt
from scipy.io.wavfile import read

WAVELET = 'db4'
LEVEL = 5
DELTA = 200.0


def chi_square_qim(coeffs, delta):
    """So sanh histogram cua coeffs mod delta voi phan bo deu."""
    mods = np.mod(coeffs, delta)
    hist, _ = np.histogram(mods, bins=20, range=(0, delta))
    expected = len(coeffs) / 20
    if expected == 0:
        return 0.0
    chi2 = float(np.sum((hist - expected) ** 2 / expected))
    return chi2


def main():
    print("=" * 60)
    print("TASK 6: BLIND STATISTICAL ANALYSIS")
    print("=" * 60)
    fs, stego = read("stego_audio.wav")
    if stego.ndim > 1: stego = stego[:, 0]
    stego = stego.astype(np.float64)
    coeffs = pywt.wavedec(stego, WAVELET, level=LEVEL)
    subband_names = ['cA5', 'cD5', 'cD4', 'cD3', 'cD2', 'cD1']
    report = ["BLIND STATISTICAL ANALYSIS", "=" * 40]
    suspicious_count = 0
    for i, name in enumerate(subband_names):
        chi2 = chi_square_qim(coeffs[i], DELTA)
        suspicious = chi2 > 100
        marker = "SUSPICIOUS" if suspicious else "normal"
        line = f"  {name}: chi2={chi2:.2f} -> {marker}"
        report.append(line)
        print(line)
        if suspicious:
            suspicious_count += 1
    report.append("")
    if suspicious_count > 0:
        report.append(f"Suspicious patterns detected o {suspicious_count}/6 sub-bands.")
        report.append("KET LUAN: NGHI NGO CO STEGANOGRAPHY (QIM-based).")
        print(f"\n>>> Suspicious patterns detected: {suspicious_count}/6")
        print(">>> KET LUAN: NGHI NGO STEGANOGRAPHY")
    else:
        report.append("KHONG phat hien dau hieu nghi ngo.")
    with open("stats_report.txt", "w") as f:
        f.write("\n".join(report))
    print(">>> Bao cao: stats_report.txt")


if __name__ == "__main__":
    main()
